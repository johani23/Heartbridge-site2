# Heartbridge MVP

This repository contains the MVP version of Heartbridge:

## Structure
- `backend/`: Flask API for processing analysis and clustering
- `frontend/`: UI for the user-facing interface
- `survey/`: Cluster-based user questionnaire

## Setup
1. Install Python packages:
```bash
pip install -r backend/requirements.txt
```
2. Run the app:
```bash
python backend/app.py
```
3. Open frontend/index.html and survey/index.html locally or host via Netlify
